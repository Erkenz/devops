const app = require("./app");
const port = process.env.PORT || 3300;

app.listen(port);
console.log("Server running (3000)");