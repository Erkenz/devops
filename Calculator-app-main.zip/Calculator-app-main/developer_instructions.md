# 2TIN DevOps Calculator
## Requirements & configuration
NodeJS 14 
```
https://nodejs.org/en/download/
```

## Testing & running the project
Install dependencies


testing & running see nodeJS scripts
